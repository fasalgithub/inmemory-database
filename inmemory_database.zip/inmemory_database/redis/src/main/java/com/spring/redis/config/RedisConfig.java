package com.spring.redis.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.spring.redis.entity.User;

@Configuration
@EnableRedisRepositories
public class RedisConfig 
{
	@Bean
	public JedisConnectionFactory getConnectionFactory() 
	{
		RedisStandaloneConfiguration standaloneConfig = new RedisStandaloneConfiguration();
		standaloneConfig.setHostName("localhost");
		standaloneConfig.setPort(6379);
		return new JedisConnectionFactory(standaloneConfig);
	}
	
	//Redis Template
	@Bean
	public RedisTemplate<String, Object> getMyRedis()
	{
		RedisTemplate<String, Object> raRedisTemplate = new RedisTemplate<>();
		raRedisTemplate.setConnectionFactory(getConnectionFactory());
		raRedisTemplate.setKeySerializer(new StringRedisSerializer());
		raRedisTemplate.setHashKeySerializer(new StringRedisSerializer());
		raRedisTemplate.setHashKeySerializer(new JdkSerializationRedisSerializer());
		raRedisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
		raRedisTemplate.setEnableTransactionSupport(true);
		raRedisTemplate.afterPropertiesSet();
		return raRedisTemplate;
	}
	

}
