package com.spring.redis.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.redis.entity.User;
import com.spring.redis.repository.UserDao;

@RestController
public class UserController 
{
	@Autowired
	UserDao userDao;
	
	@RequestMapping("/message")
	public String getMyMessge() 
	{
	 return "Hello";
	}
		
	@PostMapping("/new-user")
	public User saveUser(@RequestBody User user) 
	{
		userDao.save(user);
		return user;
	}
	
	@GetMapping("/all-user")
	public List<Object> findAllUser()
	{
		return userDao.findAllUser();
	}
	
	@GetMapping("/user/{id}")
	public User userReplacement(@PathVariable("id") int id) 
	{
	   return userDao.findUserByUserId(id);
	}
	
	@DeleteMapping("/user/{id}")
	public String userRemove(@PathVariable("id") int id) 
	{
	   return userDao.deleteUserById(id);
	}
	

}
