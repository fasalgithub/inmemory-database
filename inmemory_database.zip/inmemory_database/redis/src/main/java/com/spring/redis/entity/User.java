package com.spring.redis.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@RedisHash("User")
public @Data class User implements Serializable
{
	@Id
	private int userId;
	private String userName;
	private String tech;

}
