package com.spring.redis.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.spring.redis.entity.User;

@Repository
public class UserDao 
{
	private static final String HASH_KEY = "User";
	
	@Autowired
	private RedisTemplate<String, Object> redisTemplate;
	
	
	public User save(User user) 
	{
		redisTemplate.opsForHash().put(HASH_KEY, user.getUserId(), user);
		return user;
	}
	
	public List<Object> findAllUser()
	{
		return  redisTemplate.opsForHash().values(HASH_KEY);
	}
	
	public User findUserByUserId(int userId) 
	{
		return (User) redisTemplate.opsForHash().get(HASH_KEY, userId);
	}
     
	public String deleteUserById(int userId) 
	{
		redisTemplate.opsForHash().delete(HASH_KEY, userId);
		return "User Removed..";
	}
}
