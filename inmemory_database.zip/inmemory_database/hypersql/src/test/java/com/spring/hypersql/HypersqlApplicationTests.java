package com.spring.hypersql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HypersqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
