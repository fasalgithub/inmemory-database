package com.spring.hypersql.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.hypersql.model.User;
import com.spring.hypersql.repo.UserRepository;

@RestController
public class UserController 
{
	@Autowired
	private UserRepository userRepository;
  
	 @GetMapping("/message")
	 private String getMessage() 
	 {
		 return "Hello HyperSQL";
	 }
	 
	 @GetMapping("/all-users")
	 private List<User> getAllMyUsers()
	 {
		 return userRepository.findAll(); 
	 }
	 
	 @PostMapping("/add-user")
	 private User addUser(@RequestBody User user) 
	 { 
		userRepository.save(user); 
		return user;
	 }
	 
	
}
